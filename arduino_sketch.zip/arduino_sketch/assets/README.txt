This folder will contain weather icons for the E-Ink display.

Icon naming convention:
- 01d.bmp - Clear sky (day)
- 01n.bmp - Clear sky (night)
- 02d.bmp - Few clouds (day)
- 02n.bmp - Few clouds (night)
- etc.

Icons should be 1-bit BMP format in two sizes:
- 100x100 pixels for the current weather
- 30x30 pixels for the hourly forecast
